package com.mgb.keyboard

import android.content.Context
import android.view.View
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import com.mgb.keyboard.typing.BarSize
import com.mgb.keyboard.typing.ToolbarOrder

/** v0.2.1: MgbIme implements this: makeKey(id) returns the finished key for an item id (or "fold"), null = skip it. */
interface ToolbarHost {
    fun makeKey(id: String): Button?
}

/**
 * v0.2.1 custom toolbar (setting tb_custom; default ON since v0.2.7, OFF = the old fixed edit bar).
 * One row: fixed fold / unfold key on the left + a horizontally scrollable strip of keys built from the saved order
 * (prefs tb_order / tb_hidden, see typing/ToolbarOrder.java). Folded (pref tb_fold) = fold key + the FIRST visible item only.
 * build() returns null on any problem -> MgbIme uses the old edit bar.
 */
object Toolbar {

    private const val KEY_W = 44   // dp, fixed key width (the strip scrolls when the keys do not fit)
    private const val KEY_H = 36   // dp, same height as the old edit bar

    fun label(id: String): String = when (id) {
        "clip" -> "Clip"; "all" -> "All"; "cut" -> "Cut"; "copy" -> "Copy"; "paste" -> "Paste"; "plain" -> "Plain"
        "fmt" -> "Aa"; "mode" -> "PH"
        "emoji" -> "\u263A"; "numpad" -> "123"; "sym" -> "#+="; "gear" -> "\u2699"; "voice" -> "\uD83C\uDFA4"
        "globe" -> "\uD83C\uDF10"; "theme" -> "Th"; "onehand" -> "1H"; "size" -> "Sz"; "pad" -> "Pad"; "undo" -> "\u21B6"; "redo" -> "\u21B7"; "vault" -> "Vlt"; "tt" -> "Tt"; "profiles" -> "Pf"; "keymap" -> "Km"
        "selword" -> "SWd"; "selline" -> "SLn"; "delword" -> "DWd"; "delline" -> "DLn"; "linestart" -> "|<"; "lineend" -> ">|"; "dupline" -> "Dup"; "selnone" -> "Sel0"; "hpause" -> "H\u25CF"   // v0.16.13 (X13): edit items; v0.23.0 (H3): hpause = typing history pause
        // v0.16.5: keymap; v0.4.4; v0.4.6; v0.5.1
        else -> id
    }

    fun title(id: String): String = when (id) {
        "fmt" -> "Formatter (Aa)"; "clip" -> "Clipboard"; "mode" -> "Mode (Phone / PC)"; "all" -> "Select all"
        "cut" -> "Cut"; "copy" -> "Copy"; "paste" -> "Paste"; "plain" -> "Paste plain"
        "emoji" -> "Emoji panel"; "numpad" -> "Number pad (123)"; "sym" -> "Symbols"; "gear" -> "Settings (gear)"
        "voice" -> "Voice typing"; "globe" -> "Next keyboard"; "theme" -> "Theme (cycle)"; "onehand" -> "One-hand (cycle)"; "size" -> "Size page"; "pad" -> "Cursor / select pad"; "undo" -> "Undo"; "redo" -> "Redo"; "vault" -> "Text Vault (snippets / notes / glossary)"; "tt" -> "Text tools (count / case / clean / repeat / date)"; "profiles" -> "Profiles (layout sets)"; "keymap" -> "Key map (Bangla cheat sheet)"
        "selword" -> "Select word"; "selline" -> "Select line"; "delword" -> "Delete word"; "delline" -> "Delete line"; "linestart" -> "Line start"; "lineend" -> "Line end"; "dupline" -> "Duplicate line"; "selnone" -> "Select none"; "hpause" -> "Typing history: pause / resume"   // v0.16.13 (X13): edit items; v0.23.0 (H3)
        // v0.16.5; v0.4.4; v0.4.6
        else -> id
    }

    /** Icon name in JabraIcons (same names as the old edit bar). */
    fun icon(id: String): String = if (id == "mode") "mode_phone" else if (id == "voice") "mic" else id

    fun build(ctx: Context, prefs: JabraPrefs, host: ToolbarHost): View? = try { make(ctx, prefs, host) } catch (_: Throwable) { null }

    private fun make(ctx: Context, prefs: JabraPrefs, host: ToolbarHost): View? {
        val d = ctx.resources.displayMetrics.density
        fun dp(v: Int): Int = (v * d).toInt()
        val kw = try { BarSize.widthDp(prefs.int("tb_ipct", BarSize.DEF)) } catch (_: Throwable) { KEY_W }   // v0.16.6 (X6): 100 = 44 dp
        val kh = try { BarSize.heightDp(prefs.int("tb_hpct", BarSize.DEF)) } catch (_: Throwable) { KEY_H }   // v0.16.6 (X6): 100 = 36 dp
        fun fixed(): LinearLayout.LayoutParams {
            val lp = LinearLayout.LayoutParams(dp(kw), dp(kh))
            lp.setMargins(dp(2), dp(2), dp(2), dp(2))
            return lp
        }

        val ids = ArrayList<String>()
        for (id in ToolbarOrder.visible(prefs.str("tb_order", ""), prefs.str("tb_hidden", ""), prefs.str("tb_on", ""))) {
            if (id == "fmt" && !prefs.bool("fmt_on", true)) continue     // old setting Formatter OFF = item hidden
            if (id == "mode" && !prefs.bool("mode_key", true)) continue  // old setting Mode key OFF = item hidden
            ids.add(id)
        }
        val ordered: List<String> = try { if (prefs.bool("tb_auto", false)) com.mgb.keyboard.typing.ToolUsage.reorder(ids, prefs.str("tb_use", "")) else ids } catch (_: Throwable) { ids }   // v0.5.4: most used 3 behind the first item
        val shown: List<String> = if (prefs.bool("tb_fold", false)) ordered.take(1) else ordered

        val bar = LinearLayout(ctx)
        bar.orientation = LinearLayout.HORIZONTAL
        val fold = host.makeKey("fold") ?: return null
        fold.layoutParams = fixed()
        try { fold.contentDescription = "Toolbar: open or close" } catch (_: Throwable) { }   // v0.10.20 (W7)
        bar.addView(fold)

        val strip = LinearLayout(ctx)
        strip.orientation = LinearLayout.HORIZONTAL
        for (id in shown) {
            var k0: Button? = null
            try { k0 = host.makeKey(id) } catch (_: Throwable) { }
            val k = k0 ?: continue
            k.layoutParams = fixed()
            try { k.contentDescription = title(id) } catch (_: Throwable) { }   // v0.10.20 (W7): spoken name = the name from the toolbar editor
            strip.addView(k)
        }
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        try { hs.isHorizontalFadingEdgeEnabled = true; hs.setFadingEdgeLength(dp(16)); hs.overScrollMode = View.OVER_SCROLL_NEVER } catch (_: Throwable) { }   // v0.18: soft edge = "more keys this way"; no grey end glow
        hs.addView(strip)
        hs.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        bar.addView(hs)
        return bar
    }
}
