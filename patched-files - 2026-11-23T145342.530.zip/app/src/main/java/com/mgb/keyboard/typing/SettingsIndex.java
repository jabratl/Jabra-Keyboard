package com.mgb.keyboard.typing;

import java.util.ArrayList;
import java.util.List;

/**
 * v0.4.2 pure Java helpers for the settings screen (no Android classes, tested by tools/SettingsIndexTest.java).
 * - search(entries, query): every word of the query must appear in title + help + group + key (case-insensitive).
 * - recent list: csv of pref keys, newest first, no duplicates, max 8 (pref set_recent).
 * - last change: "key|oldValue" (pref set_last), one level of undo. Old value is an int (toggle 0/1, level / cycle index).
 * - help(key): one short grey line shown under a row. Unknown key = "" (no line).
 */
public final class SettingsIndex {
    private SettingsIndex() {}

    public static final int RECENT_MAX = 8;

    public static final class Entry {
        public final String key, title, help, group;
        public Entry(String key, String title, String help, String group) {
            this.key = key == null ? "" : key;
            this.title = title == null ? "" : title;
            this.help = help == null ? "" : help;
            this.group = group == null ? "" : group;
        }
    }

    private static String low(String s) { return s == null ? "" : s.toLowerCase(java.util.Locale.ROOT); }

    public static boolean matches(Entry e, String query) {
        if (e == null) return false;
        String q = low(query).trim();
        if (q.isEmpty()) return true;
        String hay = low(e.title) + " " + low(e.help) + " " + low(e.group) + " " + low(e.key).replace('_', ' ');
        for (String w : q.split("\\s+")) {
            if (w.isEmpty()) continue;
            if (!hay.contains(w)) return false;
        }
        return true;
    }

    public static List<Entry> search(List<Entry> all, String query) {
        List<Entry> out = new ArrayList<>();
        if (all == null) return out;
        for (Entry e : all) if (matches(e, query)) out.add(e);
        return out;
    }

    public static List<String> parseRecent(String csv) {
        List<String> out = new ArrayList<>();
        if (csv == null) return out;
        for (String p : csv.split(",")) {
            String k = p.trim();
            if (k.isEmpty() || out.contains(k)) continue;
            out.add(k);
            if (out.size() >= RECENT_MAX) break;
        }
        return out;
    }

    public static String pushRecent(String csv, String key) {
        if (key == null || key.trim().isEmpty() || key.indexOf(',') >= 0 || key.indexOf('|') >= 0) return csv == null ? "" : csv;
        List<String> cur = parseRecent(csv);
        cur.remove(key);
        cur.add(0, key);
        while (cur.size() > RECENT_MAX) cur.remove(cur.size() - 1);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < cur.size(); i++) { if (i > 0) sb.append(','); sb.append(cur.get(i)); }
        return sb.toString();
    }

    public static String encodeLast(String key, int oldValue) {
        if (key == null || key.isEmpty() || key.indexOf('|') >= 0) return "";
        return key + "|" + oldValue;
    }

    /** Returns {key, oldValue as text} or null when empty / broken. */
    public static String[] parseLast(String s) {
        if (s == null) return null;
        int i = s.lastIndexOf('|');
        if (i <= 0 || i >= s.length() - 1) return null;
        String k = s.substring(0, i);
        String v = s.substring(i + 1);
        try { Integer.parseInt(v); } catch (NumberFormatException ex) { return null; }
        return new String[] { k, v };
    }

    public static String help(String key) {
        if (key == null) return "";
        switch (key) {
            case "bn_layout": return "Which Bangla keyboard the language key uses: " + LangNames.AVRO + " (phonetic) or " + LangNames.PROBHAT + " (fixed).";
            case "bn_map": return LangNames.AVRO + " typing rules: Ridmik key map (default) or the Classic phonetic rules.";   // v0.16.3
            case "lang_tap": return "Language key tap: EN <-> Bangla (default), or cycle through all languages.";
            case "lang_fav": return "Which Bangla layout opens first when you tap the language key from English.";
            case "bn_url": return "ON = Bangla works in browser address / search bars. OFF = English only there.";   // v0.19.7
            case "lang_en_on": return "OFF = English is skipped by the language key and the space swipe. At least one mode always stays on.";   // v0.17.62 (R2)
            case "lang_order": return "The order of English, " + LangNames.AVRO + " and " + LangNames.PROBHAT + " when you swipe on space or use the cycle option of the language key.";   // v0.17.62 (R2)
            case "lang_avro_on": return "OFF hides " + LangNames.AVRO + " from the language key (English always stays).";
            case "lang_probhat_on": return "OFF hides " + LangNames.PROBHAT + " from the language key (English always stays).";
            case "numrow": return "Shows a row of digits above the letters.";
            case "numpad_auto": return "Opens the number pad by itself in number and phone fields.";
            case "bn_design": return "Ridmik look = Bangla fixed keys like Ridmik: bare signs, shift letters as small hints (hold to type), Bengali number page. Keyboard's original design = the old look.";   // v0.17.61 (R1)
            case "bn_hints": return "ON = Bangla (phonetic) keys show small 1-0 and signs like the Ridmik Avro keyboard; hold a key to type it. OFF = no hints in Bangla.";   // v0.17.54 (M2)
            case "bn_numpage": return "ON = in Bangla (phonetic) the number page (?123) has Bengali digits and the Ridmik Avro signs; hold a key for the small sign. OFF = the normal number page.";   // v0.17.55 (M3)
            case "tools_keep": return "ON = the tools row (or the suggestion row) stays on top when you open the number / symbol page (?123). OFF = the page covers it.";   // v0.17.53 (M1)
            case "pc_mode": return "Phone = normal keys. PC = extra Esc / Ctrl / F-keys / arrows rows.";
            case "mode_key": return "Shows the Phone / PC switch key in the edit bar.";
            case "pc_remember": return "OFF = the keyboard always opens in Phone mode.";
            case "pc_layer": return "ON = PC rows look like the other keys (needs the custom keyboard). OFF = old rows.";   // v0.17.50 (PC2)
            case "pc_chips": return "Shows shortcut chips (Ctrl+C, Ctrl+V ...) in the 4th PC row. OFF = that row has only More and Num. PC rows as layout keys only.";   // v0.17.51 (PC3)
            case "pc_chips_list": return "Up to 5 shortcuts, comma between, e.g. Ctrl+A,Ctrl+Shift+Z,Alt+F4. Empty = Ctrl+A C V X Z. Apps must read key events.";   // v0.17.51 (PC3)
            case "pc_frow": return "Shows the F1-F12 row in PC mode (PC rows as layout keys only).";   // v0.17.50 (PC2)
            case "pc_real_mods": return "ON = PC keys send real Ctrl / Alt / Shift / Win presses. OFF = old way.";   // v0.17.49 (PC1)
            case "bs_repeat": return "Holding backspace keeps deleting.";
            case "bs_word": return "A long hold on backspace deletes whole words.";
            case "autocap": return "Starts a sentence with a capital letter.";
            case "enter_action": return "Enter does Go / Search / Send when the app asks for it.";
            case "ds_period": return "Two quick spaces type a full stop and a space.";
            case "ds_tab": return "Two quick spaces type a tab (when the period rule does not apply).";
            case "hint_on": return "Long-press a letter to type its small hint character.";
            case "lp_accents": return "Hold a, e, i, o, u, c, n, s, y, z, l: slide to pick an accent letter (e.g. u: ù ú û ü ū).";
            case "key_press_anim": return "The key shrinks a little while you press it and springs back (smoother feel). Off = no animation.";
            case "hold_edit": return "Hold c = copy, v = paste, x = cut (works on the selected text). Off = the normal long-press hints. Your own Long-press override for that letter wins.";
            case "clip_undo_n": return "How many deleted clips are kept so you can bring them back: Undo restores the last delete, Deleted (in the \u22EF menu) lists them all. 0 = off. Never leaves the phone.";   // v0.18.4
            case "clip_tidy": return "Clipboard rows look like the cards: pin on the left, x on the right, small info line under the text. OFF = old rows. Needs Clipboard new look.";   // v0.18.4
            case "clip_img": return "Shows copied pictures and screenshots (max 8, kept only on the phone) on top of the clipboard. Tap = paste, hold = delete. Cleared with the clipboard history.";
            case "lp_punct": return "Hold , or . to slide over more symbols (2-row grid). Lift without moving = the old long-press.";
            case "theme": return "Colour theme of the keyboard (picker is inside the keyboard).";
            case "look": return "Classic = old square keys. Jabra = round keys, pill space key.";
            case "key_border": return "Draws or removes the border around keys.";
            case "onehand": return "Moves the keyboard to the left or right side.";
            case "icons_on": return "Own drawn icons on function keys. OFF = text labels.";
            case "nr_hpct": return "Height of the number row. 100% = the old height.";   // v0.16.7
            case "nr_mode": return "Digits, digits with a symbol on long-press, or your own characters.";   // v0.16.7
            case "nr_chars": return "Your own number-row characters (up to 10). Used by My characters.";   // v0.16.7
            case "numrow_large": return "Makes the number row a bit taller.";
            case "space_lang": return "Swipe left / right on the space key to switch language at once. Cursor drag on space is off while this is ON.";
            case "sp_preview": return "Shows the active language in a bubble while you swipe on space. Needs Space swipe ON.";
            case "key_lang": return "Hide the language (EN) key. Works only while Space swipe is ON (else the key stays).";
            case "tb_tip": return "Hold a toolbar icon for 0.3 s to see its name above it.";
            case "numrow_bn": return LangNames.AVRO + " / " + LangNames.PROBHAT + " show Bangla digits on the number row; hold a key for the Latin digit.";
            case "hint_digits": return "Number row shows a small Bangla digit; hold the key to type it.";
            case "app_tips": return "Smart = help opens from the (i) icon. Always = under every setting. Off = hidden.";   // v0.17.78 (U3)
            case "hint_mode": return "Smart = readable colour, hidden on tiny keys. Always = as set. Off = none.";   // v0.17.82 (U6)
            case "hint_size_lv": return "Size of the small hint characters (Normal = as before).";
            case "hint_alpha_lv": return "How strong the small hint characters look (Normal = as before).";
            case "hint_hide": return "Hides the small hint letters; long-press still works.";
            case "fb_down": return "Vibration / sound the moment your finger touches a letter or number key (not when you lift). Backspace, space and Shift keep their own timing.";
            case "haptic_native": return "Uses the phone's own key-tap vibration (strength level is ignored). OFF = the Vibration strength setting.";
            case "haptic": return "Short vibration on every key press.";
            case "sound": return "Click sound on every key press.";
            case "key_popup": return "Shows a bubble with the letter above the pressed key.";
            case "row_gap": return "Home row (a-l): same key width as the row above, half a key of free space on each side. A tap in the free space types the nearest key. ON = default.";   // v0.10.25
            case "kh_pct_p": return "Key height in portrait. 100% = 48 dp. The picture at the top shows it.";   // v0.10.25
            case "key_gap": return "Space between keys in dp. Smaller gap = bigger keys.";   // v0.10.25
            case "edge_dp": return "Space between the screen edge and the first key. Smaller = wider keys. 2 dp = old.";   // v0.10.26
            case "row_vgap": return "Up-down space between key rows. Not set = same as Key gap.";   // v0.10.26
            case "key_radius": return "Roundness of the keys in dp (Jabra look only; Look group). 9 = old, Ridmik is about 6.";   // v0.10.28
            case "bot_style": return "Bottom row widths. Ridmik-like: ?123 and Enter same width, space a bit shorter. Old = as before.";   // v0.10.27
            case "key_dots": return "Three small dots on keys with a long-press action (?123, language key, comma). OFF = none.";   // v0.10.27
            case "pb_home_gap": return LangNames.PROBHAT + " home row: half-key gap at the left like Ridmik. The extra key (ৃ / ঞ) becomes half width at the right. Needs Home row side gap ON.";   // v0.10.27
            case "fn_gap": return "Extra space between Shift / Backspace and the letters. 0 = old. Ridmik uses about 4 dp.";   // v0.10.26
            case "letter_pct": return "Letter size. 100% = normal.";   // v0.10.25
            case "letter_bold": return "Bold letters on the keys.";   // v0.10.25
            case "oh_w_p": return "Width of the keyboard in one-hand mode (portrait). Needs One-hand Left or Right.";   // v0.10.25
            case "pop_ref": return "Bigger rounded key bubble in your theme colour (needs Key popup ON). OFF = old look.";   // v0.9.6
            case "sp_punct": return "After a word + space, typing , . ! ? removes that space (hello, not hello ,).";   // v0.10.6; v0.17.34 (M1): also after the space key
            case "ac_on": return "Fixes 1-letter English typos on space. Backspace right after undoes it. OFF = never.";   // v0.10.3
            case "learn_on": return "Learns words you type (kept on this phone only) and suggests them. OFF = nothing stored.";   // v0.10.2
            case "ap_on": return "Uses the profile you set for an app (Profiles > App) when its field opens. OFF = never.";   // v0.10.19
            case "qa_on": return "Select text: the top row shows Copy, Case, Clean and the word count. Needs Suggestion row. OFF = normal.";   // v0.10.23
            case "sg_on": return "Word suggestions in the top row; the left icon opens the toolbar. OFF = toolbar only.";   // v0.10.1
            case "pop_fast": return "Draws the key bubble inside the keyboard: smoother (needs Key popup ON). OFF = old.";   // v0.9.9
            case "sp_tick": return "Soft tick for every language step while you swipe on space. Needs Space swipe ON.";   // v0.9.8
            case "sp_step": return "How far to swipe on space for one language step: Small, Normal or Large.";   // v0.9.8
            case "h_lock": return "Keyboard keeps the same height in English, " + LangNames.AVRO + " and " + LangNames.PROBHAT + " (no jump). OFF = old.";   // v0.9.7
            case "key_globe": return "Shows a key to switch to the next keyboard.";
            case "key_voice": return "Shows a key that opens the phone's voice typing.";
            case "sp_wpct": return "Width of the space bar. 100% = normal. The other keys get narrower when it is wider.";   // v0.17.2 (K2)
            case "sp_hpct": return "Height of the whole bottom row (space, ?123, Enter ...). 100% = normal.";   // v0.17.2 (K2)
            case "sp_anim": return "The language name slides with your finger on space. Needs Space swipe ON.";   // v0.17.2 (K2)
            case "kb_custom": return "Experimental: English letter rows from the saved layout. Off = the normal keyboard.";   // v0.17.5 (K5a.1)
            case "key_qm": return "Shows a ? key (Bangla: ।) before the dot. OFF = wider space; long-press the dot for it.";   // v0.17.1 (K1)
            case "danda_key": return "Bangla: the dot key is ।, long-press gives the full stop. Needs the ? / । key hidden.";   // v0.17.18 (L1)
            case "key_emoji": return "Shows an emoji key next to the language key.";
            case "lp_delay": return "How long you must hold a key for a long-press.";
            case "cursor_speed": return "How fast the cursor moves when you drag on the space key.";
            case "edit_bar": return "The toolbar row above the letters (Aa, clipboard, select, copy...).";
            case "clip_on": return "Saves copied text in the clipboard history.";
            case "fmt_on": return "Shows the Aa novel formatter button.";
            case "fmt_float": return "Formatter: after Preview, the exact result floats over the screen and updates live. OFF = a small box inside the panel.";   // v0.45.7
            case "pad_delay": return "Cursor pad: auto-open delay - Instant / Short / Normal / Long.";   // v0.48.1
            case "pad_speed": return "Cursor pad: trackpad (drag) speed - Slow / Normal / Fast.";   // v0.48.0
            case "pad_extra": return "Cursor pad: extra rows with Word, PgUp / PgDn, Line, Undo, Redo. OFF = the 4 old rows.";   // v0.45.4
            case "clip_lines": return "How many lines of each clip are shown in the clipboard.";
            case "clip_view": return "Clipboard as a list or as 2-column cards.";
            case "clip_order": return "Which group comes first in the clipboard: Pinned or Recent (List and Cards).";   // v0.15.2
            case "clip_sort": return "Order of clips in the clipboard: Newest, Oldest, A-Z or Most used.";
            case "clip_count": return "Shows the number of characters (and paste count) on each clip.";
            case "clip_expire": return "Deletes unpinned clips after this time. Pinned clips are never deleted.";
            case "clip_new_look": return "Neater clipboard: title + count, one filled Add button, a \u22EF menu for Manage / Sort / View / Export all / Clear, clearer empty texts, 1-2 clips delete with Undo. OFF = old panel.";   // v0.17.58 (C3)
            case "clip_tight": return "Clipboard tight cards: smaller padding and minimum height, small check box (select mode), smaller Aa tag, one small dim info line, so more clips fit. OFF = old card size. Needs the new look.";   // v0.36.0 (CC4)
            case "clip_pop": return "Clipboard popup menus: More in select mode and the 3-dot menu open as a floating menu over the list (nothing is pushed down). OFF = the old in-panel trays. Needs the new look.";   // v0.35.1 (CC3-B)
            case "clip_fold": return "Clipboard: tap the title to hide the Filter row, tap the arrow before Pinned / Recent to fold it. Select mode and search show all. OFF = nothing folds. Needs the new look.";   // v0.43.0
            case "clip_paste2": return "Select mode: if a selected clip has a format, Paste becomes Aa (with format) and T (plain text). OFF = one Paste button. Needs the new look.";   // v0.43.0
            case "clip_float": return "Clipboard floating select bar: Pin / Delete / Paste / More float as a rounded pill over the list, only while clips are selected. OFF = the slim bar under the list. Needs the new look.";   // v0.37.0
            case "clip_slimbar": return "Clipboard select mode: slim bottom bar (Pin, Delete, Paste, More with a small icon and one word) and the selected count shown in Done. OFF = old bar. Needs the new look and the compact header.";   // v0.35.0 (CC3-A)
            case "clip_compact2": return "Clipboard: Undo becomes a small arrow at the end of the filter row and the count line is dropped, so more clips show. OFF = old two rows. Needs the new look.";   // v0.34.0 (CC2)
            case "clip_compact": return "Clipboard top row (ABC, Search, Done) is lower and the padding smaller, so more of the copied text shows. OFF = old header. Needs Clipboard new look.";   // v0.33.0 (CC1)
            case "clip_fit": return "Clipboard opens as tall as the keyboard (no shrink). OFF = old fixed size.";   // v0.15.1
            case "panel_ui": return "New panels (Clipboard, Vault, Gear, More, Toolbar): Classic = old, New = chips / tiles.";   // v0.16.12 (X12)
            case "clip_list_pct": return "Height of the clip list. Smaller = shorter list. 100% = as tall as the keyboard.";   // v0.17.38 (M5)
            case "clip_fmt_tap": return "Card tap pastes with format; tap Aa for the other way. Some apps paste plain anyway.";   // v0.17.40 (M7)
            case "clip_stay": return "After tapping a clip it is pasted and the clipboard stays open. OFF = back to letters.";   // v0.17.37 (M4)
            case "clip_card_pct": return "Size of the clip cards. Smaller = more text and more clips fit. 100% = normal.";   // v0.17.33 (UI9)
            case "clip_btn_pct": return "Size of the Clipboard buttons. Smaller = the clip list shows more. 100% = normal.";   // v0.17.32 (UI8)
            case "clip_hold": return "How long to hold a clip to start select mode. System = the old long-press.";   // v0.16.16 (E2)
            case "clip_simple": return "Quiet clipboard (list + cards): pin on the right, no x. OFF = the old card look.";   // v0.19.8
            case "ui_pill": return "Clipboard filter, sort and view as small dropdowns. OFF = the old chip rows.";   // v0.19.1
            case "clip_pwd": return "Saves copied passwords (password managers) in the clip history. OFF = never saved.";   // v0.18.12
            case "clip_sens": return "Removes copied one-time codes (4-8 digits, short codes) after 2 minutes.";   // v0.10.10
            case "tb_vault": return "Shows the Vault key on the toolbar (saved texts, terms and templates).";   // v0.7.1
            case "kh_pct_l": return "Key height in landscape (sideways). Unset = the old level.";   // v0.15.4
            case "oh_w_l": return "Width of the keyboard in one-hand mode (landscape).";   // v0.15.4
            case "tb_custom": return "Custom = your own toolbar (order, hide). Classic = the old fixed bar.";   // v0.15.4
            case "tb_auto": return "Moves the tools you use most to the front of the toolbar.";   // v0.15.4
            case "tb_fold": return "Folds the toolbar to its first tool. The \u00AB key on the bar does the same.";   // v0.15.4
            case "tb_hpct": return "Height of the toolbar keys. 100% = the old size.";   // v0.16.6
            case "tb_ipct": return "Size of the toolbar icons / text and key width. 100% = the old size.";   // v0.16.6
            case "hint_custom": return "Your own long-press characters: a=@,e=3 (letter=text). Empty = normal.";   // v0.15.4
            case "xrow_chars": return "Extra row of up to 10 characters above the numbers. Empty = no row.";   // v0.15.4
            case "vault_sort": return "Order of the Vault list: Newest, A-Z or most Used.";   // v0.15.4
            case "vault_dest": return "Vault folder that \"To Vault\" from the clipboard saves into.";   // v0.15.4
            default: return "";
        }
    }
}
